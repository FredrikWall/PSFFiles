<#
  .SYNOPSIS
	    Install Visual Studio Code
		
  .DESCRIPTION
        Installs Visual Studio Code
  
  .NOTES
    Author: 	Fredrik Wall
    Email:		fredrik.wall@retune.se
    Created:	2020-12-03
    Version:    1.0
#>

$PSFSetupFolder = "C:\PSFSetup"
$TranscriptFileName = "Install-VSCode.ps1.log"

# Check if the setup and logs folder exists
if (-not (Test-Path -Path $PSFSetupFolder)) {
  New-Item $PSFSetupFolder -ItemType Directory
}

if (-not (Test-Path -Path "$PSFSetupFolder\Logs")) {
  New-Item "$PSFSetupFolder\Logs" -ItemType Directory
}

# Starts Transcript
Start-Transcript -Path "$PSFSetupFolder\Logs\$TranscriptFileName" -Append

Install-Package NuGet -Force
Install-Script Install-VSCode -Scope CurrentUser -Force
& $env:USERPROFILE\Documents\WindowsPowerShell\Scripts\Install-vscode.ps1

# Stops Transcript
Stop-Transcript

